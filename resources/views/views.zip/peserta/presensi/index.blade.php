@extends('peserta.master')
@section('title',"Presensi")

@section('subTitle',"Presensi")

@section('content')
<div class="row justify-content-center h-100 align-items-center">
    <div class="col-md-5">
        <div class="form-input-content text-center error-page">
            <h6 class="error-text font-weight-bold">MAAF</h6>
            <h4> maintenance</h4>
            <p>Fitur ini sedang maintenance</p>

        </div>
    </div>
</div>
@endsection